const hamburgerButtonElement = document.querySelector("#hamburger");
const topnav = document.querySelector(".topnav");
const drawerElement = document.querySelector(".sidenav");
const mainElement = document.querySelector("body");

document.addEventListener("DOMContentLoaded", () => {
	const navList = `<li><a href="/"><i class="material-icons">home</i> Home</a></li>
		<li><a href="#"><i class="material-icons">favorite</i> Favorite</a></li>
		<li><a href="https://www.linkedin.com/in/dhanadhira/"><i class="material-icons">info</i> About Us</a></li>`;
	topnav.innerHTML = navList;
	drawerElement.innerHTML = navList;
});

hamburgerButtonElement.addEventListener("click", (event) => {
	drawerElement.classList.toggle("open");
	event.stopPropagation();
});

mainElement.addEventListener("click", (event) => {
	drawerElement.classList.remove("open");
	event.stopPropagation();
});
