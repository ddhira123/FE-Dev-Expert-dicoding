import "regenerator-runtime"; /* for async await transpile */
import "../styles/main.scss";
import "./navbar.js";
import "./footer.js";
import "./list.js";
